myConstant = 2
myCount = 0
myList = []

def appendList():
    myList.append( myConstant )
    
def increaseCount():
    #global myCount
    myCount = myCount + myConstant
    
def main():
    for x in range(5):
        appendList()
        increaseCount()
        print myList
        print myCount
    
main()






