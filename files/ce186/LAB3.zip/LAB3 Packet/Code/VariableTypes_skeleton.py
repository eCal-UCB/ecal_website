
def main():
    myString = "Hello "
    myInt = 186
    myFloat = 3.14159

    
main()
    





