
def main():
  # For Loop Examples
  
  print "Start for loop #1"
  for i in range(0,3):
    print i

  print "Start for loop #2"
  for j in range(0,9,2):
    print j

  print "Start for loop #3"
  for k in range(0,20):
    print k
    if k == 12:
      break

  print "Start for loop #4"
  string = "Hello"
  for x in string:
    print x
    
  print "Start for loop #5"
  listOfInts = [ 1, 3, 5, 7 ]
  for x in listOfInts:
    print x
    
main()


