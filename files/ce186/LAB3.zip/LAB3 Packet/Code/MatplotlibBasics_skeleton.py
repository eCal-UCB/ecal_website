'''
matplotlib Basics
Lab 3: Exercise 5
'''

import numpy as np
import datetime
import matplotlib.pyplot as plt
from matplotlib.dates import DateFormatter, HourLocator, MinuteLocator
plt.close("all")

# Convert UTC datetime to UNIX time
def to_unix_time(dt):
    epoch = datetime.datetime.utcfromtimestamp(0)
    delta = dt - epoch
    return delta.total_seconds()

# Convert UNIX time to UTC datetime
def from_unix_time(sec):
    epoch = datetime.datetime.utcfromtimestamp(0)
    delta = datetime.timedelta(seconds=sec)
    return epoch+delta
 
