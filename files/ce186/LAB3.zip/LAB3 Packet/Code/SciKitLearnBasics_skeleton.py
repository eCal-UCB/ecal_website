'''
Linear Regression with SciKit Learn
Lab 3: Exercise 6
'''

import numpy as np
import datetime
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
plt.close("all")

