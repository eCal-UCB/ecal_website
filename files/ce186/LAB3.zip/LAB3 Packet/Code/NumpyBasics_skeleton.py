'''
NumPy Basics
Lab 3: Exercise 4
'''

import numpy as np

myList = [1,2,3,4]

