
    def main():
        myList = [1,1,2,3,5]

        # Just try it
        try:
            print myList[ 10 ]
        except:
            print "Oops, something went wrong"

        # Program does not "crash"
        print "Still running"
        
    main()
    


