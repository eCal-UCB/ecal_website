

def strToInt( string ):
    returnInt = 0
    return returnInt

def main():
    intString = "186"
    num = strToInt( intString )
    print type(num)

main()
