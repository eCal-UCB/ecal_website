
# Import built-in module
import time

def main():
    # Print time module
    print time

    # time.time returns the number of
    # seconds since epoch (1970 for Unix)
    now = time.time()
    print now
    
    # localtime() method returns time.struct_time object
    current = time.localtime()
    # Print the object
    print current
    # time.struct_time variables can be accessed by name
    # or by index
    print "Current Minute:", current.tm_min
    print "Current Minute:", current[4]

    # time delay in seconds
    time.sleep( 2 )
    print time.localtime()
    

main()

