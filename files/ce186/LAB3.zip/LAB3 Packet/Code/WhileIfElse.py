
def main():
    count = 1
    while count < 20:
        if count <= 5:
            print count, "<= 5"
        elif count <= 10:
            print count, "<= 10"
        elif count <= 15:
            print count, "<= 15"
        else:
            print count, "> 15"

        if count < 5 or count > 10:
            print "Or"
        if count > 5 and count < 10:
            print "And"
        count += 1

main()

