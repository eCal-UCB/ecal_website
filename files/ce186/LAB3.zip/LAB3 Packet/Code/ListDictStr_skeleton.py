# Reference:
# docs.python.org/2/tutorial/datastructures.html

def main():
    # Lists (list) can store any data type.
    myList = [1, 1, 2, 3, 5, 8, 13]
    myStringList = ["one","two","three"]
    myOtherList = [1, "one", 1.00, True]

    # Dictionaries (dict) can store key/value pairs.
    myDictionary = {
        "key":"value",
        "class":186,
        1: "UCB",
        "list": myList
    }
    # Strings (str or unicode) can be thought
    # of as lists of characters.
    myString = "Hello"
    
    
    # Below is a dictionary where each value is a list of dictionaries
    myData = {
        "temperature":[
            {"at":0, "reading":78},
            {"at":1, "reading":80},
            {"at":2, "reading":83}
        ]
    }

    # Items in a list are assigned or retrieved
    # using the index (starting at zero).
    firstItem = myOtherList[0]

    # Items in a dict are assigned or retrieved
    # using a key.
    value = myDictionary["key"]
    
    # The range() function can generate a list of ints
    # given a start, end, and step.
    myIntList = range(0,10,2)
    
    # len() function returns the length of a list, dict, or str
    listLength = len( myList )

    # In Python, lists are also objects with built-in method.
    print "List Methods"
    print "Length: ", len( myList )
    # Add data to the end
    myList.append( 21 )
    print "Length: ", len( myList )
    # Remove and return item
    print "Popped: ", myList.pop( 2 )
    print "Length: ", len( myList )
    # Find the index of a value
    print "Index of 8 is: ", myList.index( 8 )
    print



    # Complete each of the following
    # with one line of code.
    print "To Complete:"
    # 1. Print the last item in myList
    print 

    # 2. Print the number of items in myDictionary
    print 

    # 3. Print the value 186 from the myDictionary
    print 
    
    # 4. Print the first character myString (i.e "H")
    print 

    # 5. Print the second character of the first string
    # in myStringList (i.e "n")
    print 
    
    # 6. Print the "first temperature reading" from myData
    print 
    
    # 7. Using range(), print the list [0,3,6]
    print 

    
main()
