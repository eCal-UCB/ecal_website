# -*- coding: utf-8 -*-
"""
Created on Sat May 30 18:12:36 2015

@author: eric
"""


# Import requests and json modules
import requests
import json

def main():
    base = 'http://127.0.0.1:5000/'
    endpoint = 'network/CE186/object/Arduino/stream/Temperature'
    address = base + endpoint
    
    # Set query (i.e. http://url.com/?key=value).
    query = {}
    # Set header.
    header = {'Content-Type':'application/json'}
    
    # Set body (also referred to as data or payload). Body is a JSON string.
    payload = [
        {'value':67}
    ]
    body = json.dumps(payload)
    
    # Form and send request. Set timeout to 2 minutes. Receive response.
    r = requests.request('post', address, data=body, params=query, headers=header, timeout=120 )

    print r.url
    # Text is JSON string. Convert to Python dictionary/list
    print r.text
    #print json.loads( r.text )
    

    # Read data
    query = {'limit':100}
    
    # Form and send request. Set timeout to 2 minutes. Receive response.
    r = requests.request('get', address, params=query, timeout=120 )

    print r.url
    # Text is JSON string. Convert to Python dictionary/list
    print r.text
    #print json.loads( r.text )
    
main()