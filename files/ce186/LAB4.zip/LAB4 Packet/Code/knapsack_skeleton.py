
# Import requests and json modules
import requests
import json

def main():
    # Optimization Example:
    
    # Using an Application Programming Interface (API) for the
    # Cloud Optimization Solver App: Results returned in JSON format.
    # Set url address.
    base = 'http://127.0.0.1:5000'
    endpoint = '/v1/solve/milp'
    address = base + endpoint

    # Set query (i.e. http://url.com/?key=value).
    query = {'api_key':'YOUR_API_KEY_HERE'}
    # Set header.
    header = {'Content-Type':'application/json'}

    # Formulate LP problem
    c = []
    A = []
    b = []
    E = []
    d = []
    integers = []
    bounds = [["Default",0,"None"]]
    # Set body (also referred to as data or payload). Body is a JSON string.
    payload = {'c':c,'r':0,'A':A,'b':b,'E':E,'d':d,'integer': integers,'bounds':bounds}
    body = json.dumps(payload)

    # Form and send request. Set timeout to 2 minutes. Receive response.
    r = requests.request('post', address, data=body, params=query, headers=header, timeout=120 )

    print r.url
    # Text is JSON string. Convert to Python dictionary/list
    #print r.text
    print json.loads( r.text )

main()




