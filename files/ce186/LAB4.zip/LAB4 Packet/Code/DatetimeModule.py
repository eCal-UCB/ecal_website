
# Import built-in datetime module
# Reference: http://docs.python.org/2/library/datetime.html
import datetime
# same as:
# import datetime.datetime


# Convert UTC datetime to UNIX time.
# The to_unix_time function accepts a 
# Python datetime object and returns a float.
def to_unix_time(dt):
    epoch = datetime.datetime.utcfromtimestamp(0)
    delta = dt - epoch
    return delta.total_seconds()

# Convert UNIX time to UTC datetime.
# The from_unix_time function accepts
# a float or int and returns
# a Python datetime object.
def from_unix_time(sec):
    epoch = datetime.datetime.utcfromtimestamp(0)
    delta = datetime.timedelta(seconds=sec)
    return epoch+delta
    
    
def main():
    print "Datetime module:", datetime
    # Get date object from datetime module 
    date_obj = datetime.date
    print "Date:", date_obj
    # Print today's date
    print "Today's date:", date_obj.today()

    # Get datetime object from datetime module 
    print "Datetime:", datetime.datetime
    # utcnow() returns the current 
    # Coordinated Universal Time (UTC) timestamp
    dt_obj_now = datetime.datetime.utcnow()
    print "Datetime object:", dt_obj_now
    # Print UTC using ISO 8601 format: YYYY-MM-DDTHH:MM:SS.mmmmmmZ
    print "Current date/time (ISO 8601):", dt_obj_now.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    
    # Convert to UNIX time (float)
    print "Current date/time (UNIX):", to_unix_time( dt_obj_now )
    # Convert to UNIX time (int)
    print "Current date/time (UNIX):", int( to_unix_time( dt_obj_now ) )
    
    # Create datetime object from ISO 8601 format UTC timestamp
    dt_obj_then = datetime.datetime.strptime("2015-08-26T14:00:00.000000Z", "%Y-%m-%dT%H:%M:%S.%fZ")
    print "Datetime object from ISO 8601 timestamp:", dt_obj_then
    
    # Create datetime object from UNIX timestamp
    dt_obj_epoch = from_unix_time( 0 )
    print "Datetime object from UNIX timestamp:", dt_obj_epoch
    

main()

