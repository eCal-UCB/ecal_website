
# Import requests and json modules
import requests
import json

def main():
    # Optimization Example:
    
    # Using an Application Programming Interface (API) for the
    # Cloud Optimization Solver App: Results returned in JSON format.
    # Set url address.
    base = 'http://127.0.0.1:5000'
    endpoint = '/v1/solve/lp'
    address = base + endpoint

    # Set query (i.e. http://url.com/?key=value).
    query = {'api_key':'YOUR_API_KEY_HERE'}
    # Set header.
    header = {'Content-Type':'application/json'}

    # Formulate LP problem
    c = [-400,-200]
    A = [[50,30],[24,33],[1,-1]]
    b = [40*60,35*60,0]
    E = []
    d = []
    bounds = [["Default",0,"None"]]
    # Set body (also referred to as data or payload). Body is a JSON string.
    payload = {'c':c,'r':0,'A':A,'b':b,'E':E,'d':d,'bounds':bounds}
    body = json.dumps(payload)

    # Form and send request. Set timeout to 2 minutes. Receive response.
    response = requests.request('post', address, data=body, params=query, headers=header, timeout=120 )

    print response.url
    # Text is JSON string. Convert to Python dictionary/list
    #print response.text
    print json.loads( response.text )

main()


