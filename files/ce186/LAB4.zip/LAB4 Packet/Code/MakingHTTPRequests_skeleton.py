'''
 Import Requests Module.
    You can make HTTP requests to websites and web APIs with the requests module.

    Method:
        The requests.request() method constructs a Request object, prepares it, sends it, and returns a Response object. Method
        includes several optional parameters using **kwargs (stands for keyworded arguments).

    Usage:
        requests.request(method, url, params=None, data=None, headers=None, cookies=None, files=None, auth=None,
            timeout=None, allow_redirects=True, proxies=None, hooks=None, stream=None, verify=None, cert=None)
        
    Parameters:	
        method - method for the new Request object.
        url - URL for the new Request object.
        params - (optional) Dictionary or bytes to be sent in the query string for the Request.
        data - (optional) Dictionary or bytes to send in the body of the Request.
        headers - (optional) Dictionary of HTTP Headers to send with the Request.
        cookies - (optional) Dict or CookieJar object to send with the Request.
        files - (optional) Dictionary of 'filename': file-like-objects for multipart encoding upload.
        auth - (optional) Auth tuple or callable to enable Basic/Digest/Custom HTTP Auth.
        timeout - (optional) Float describing the timeout of the request.
        allow_redirects - (optional) Boolean. Set to True by default.
        proxies - (optional) Dictionary mapping protocol to the URL of the proxy.
        stream - (optional) whether to immediately download the response content. Defaults to False.
        verify - (optional) if True, the SSL cert will be verified. A CA_BUNDLE path can also be provided.
        cert - (optional) if String, path to ssl client cert file (.pem). If Tuple, ('cert', 'key') pair.

    GET Request Examples:
        r = requests.request('get','https://www.google.com/',params={'q':'berkeley'})
        r = requests.request('get','https://www.google.com/',timeout=100,params={'q':'berkeley'})
        Note: Order of optional parameters is not defined. Therefore, you must note which parameter is being assigned.

    POST Request Example:
        r = requests.request('post','http://example.com/',data="{'key':'value'}",headers={'Content-Type':'application/json'})
        Note: In this example, the data is a JSON string
'''
import requests
'''
 Import JSON Module.
    JSON stands for JavaScript Object Notation, which is a standard format that uses human-readable
    text to transmit data objects. With the JSON module, Python lists and dictionaries can be
    converted to and from JSON strings.

    Method:
        The json.dumps() method serializes a Python object and returns a JSON formatted string.
    Usage:
        json.dumps( obj )
    Example:
        json.dumps(['foo', {'bar': ('baz', None, 1.0, 2)}])

    Method:
        The json.loads() method deserializes a JSON string and returns a Python object.
    Usage:
        json.loads( string )
    Example:
        json.loads('["foo", {"bar":["baz", null, 1.0, 2]}]')
'''
import json


