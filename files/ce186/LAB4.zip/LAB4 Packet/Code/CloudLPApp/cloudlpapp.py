import os
from flask import Flask, request
# Import PuLP modeler functions
from pulp import *
import json
from mylpclass import lp_class

app = Flask(__name__, static_url_path='')

@app.route('/', methods=['GET'])
def root():
    return app.send_static_file('index.html') # File should be in 'static' directory
    
        
@app.route('/v1/solve/lp', methods=['GET','POST'])
def lp():
    jsonData = {}
    try:
        key = request.args.get('api_key', '')
        if key == '':
            return '{"code":0,"message":"No API Key Provided (Add the API Key to the query string)"}'
        elif key != "ce186":
            return '{"code":0,"message":"Invalid API Key"}'
        
        if request.method == 'POST':
            jsonData = request.get_json()
            #r += json.dumps( jsonData)
            
            warning = ""

            if 'integer' in jsonData:
                warning += "The endpoint '/v1/solve/lp' does not accept integer constraints. Try the '/v1/solve/milp' endpoint."
                jsonData["integer"] = []
            if 'binary' in jsonData:
                warning += "The endpoint '/v1/solve/lp' does not accept binary constraints. Try the '/v1/solve/milp' endpoint."
                jsonData["binary"] = []                
            myLP = lp_class( jsonData )
            
            if not myLP.check():
                return json.dumps(myLP.message)
            
            myLP.solve()

            if len(warning)>0:
                myLP.message["warning"] = "Warning: "+warning
                
            return json.dumps(myLP.message)

        return '{"code":0,"message":"No data recieved"}'
    except:
        return '{"code":0,"message":"An unknown error occured"}'

@app.route('/v1/solve/milp', methods=['GET','POST'])
def milp():
    jsonData = {}
    try:
        key = request.args.get('api_key', '')
        if key == '':
            return '{"code":0,"message":"No API Key Provided"}'
        elif key != "ce186":
            return '{"code":0,"message":"Invalid API Key"}'
        
        if request.method == 'POST':
            jsonData = request.get_json()

            myLP = lp_class( jsonData )

            if not myLP.check():
                return json.dumps(myLP.message)
            
            myLP.solve()

            return json.dumps(myLP.message)

        return '{"code":0,"message":"No data recieved"}'
    except:
        return '{"code":0,"message":"An unknown error occured"}'

# Run the app
if __name__ == '__main__':
    app.run()