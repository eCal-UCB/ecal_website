
# Import requests and json modules
import requests
import json

# Send an HTTP request to store
# a name in the NameServer
def storename( name_dict ):
    # Send (POST) a name to the NameServer
    # Set url address.
    base = 'http://127.0.0.1:5000'
    endpoint = '/storename'
    address = base + endpoint

    # Set query (i.e. http://url.com/?key=value).
    query = {}
    # Set header.
    header = {'Content-Type':'application/json'}

    # Set body (also referred to as data or payload). Body is a JSON string.
    body = json.dumps( name_dict )

    # Form and send request. Set timeout to 2 minutes. Receive response.
    response = requests.request('post', address, data=body, params=query, headers=header, timeout=120 )

    # Text is JSON string. Convert to Python dictionary/list
    print json.loads( response.text )


# Retrieve the last 5 names in the NameServer
def retrievename():
    # Retrieve (GET) names from the NameServer
    # Set url address.
    base = 'http://127.0.0.1:5000'
    endpoint = '/retrievename'
    address = base + endpoint
    
    # Form and send request. Set timeout to 2 minutes. Receive response.
    response = requests.request('get', address, timeout=120 )

    # Text is JSON string. Convert to Python dictionary/list
    print json.loads( response.text )
    
    
    
def main():
    # Create a list of names
    names_list = [
        {'firstname':'Harry','lastname':'Potter'},  
        {'firstname':'Hermione','lastname':'Granger'},
        {'firstname':'Ronald','lastname':'Weasley'},
        {'firstname':'Neville','lastname':'Longbottom'},
        {'firstname':'Luna','lastname':'Lovegood'}
    ]
    
    # Send an HTTP request to store
    # each name in the NameServer
    for name in names_list:
        storename( name )
        
    # Retrieve the last 5 names to be stored
    retrievename()

main()


