from flask import Flask, request, jsonify

app = Flask(__name__)


# Routes
@app.route('/')
def root():
  return "Hello"
  
'''




 New Code Here




'''


# Start the app
if __name__ == '__main__':
    app.run()